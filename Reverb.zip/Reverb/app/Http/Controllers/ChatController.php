<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    public function index(User $user)
    {
        $authId = Auth::id();
        $receiverId = $user->id;

        $messages = Chat::where(function ($q) use ($authId, $receiverId) {
                $q->where('sender_id', $authId)
                  ->where('receiver_id', $receiverId);
            })
            ->orWhere(function ($q) use ($authId, $receiverId) {
                $q->where('sender_id', $receiverId)
                  ->where('receiver_id', $authId);
            })
            ->orderBy('created_at')
            ->get();

        return view('chat.index', compact('user', 'messages'));
    }

    public function store(Request $request, User $user)
    {
        $request->validate([
            'message' => 'required|string',
        ]);

        Chat::create([
            'sender_id' => Auth::id(),
            'receiver_id' => $user->id,
            'message' => $request->message,
        ]);

        return back();
    }
}
