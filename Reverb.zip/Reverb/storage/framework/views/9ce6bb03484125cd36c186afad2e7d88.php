<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/">MyApp</a>

        <div>
            <?php if(auth()->guard()->check()): ?>
                <span class="me-3">Hi, <?php echo e(auth()->user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline-dark btn-sm">Logout</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-dark btn-sm me-2">Login</a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-dark btn-sm">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="container py-5">
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH F:\New folder\xamp\htdocs\laravel\Reverb\resources\views/layouts/app.blade.php ENDPATH**/ ?>