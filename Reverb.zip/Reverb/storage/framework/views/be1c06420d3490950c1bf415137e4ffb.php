<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold mb-0">Chats</h4>

            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-dark btn-sm">Logout</button>
            </form>
            <?php endif; ?>
        </div>

        
        <div class="list-group shadow-sm">

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group-item d-flex align-items-center gap-3">

                <a href="<?php echo e(route('chat.index', $user->id)); ?>"
                    class="list-group-item d-flex align-items-center gap-3 list-group-item-action">

                    <div class="avatar border py-1 px-2 bg-black text-white fw-bold rounded-circle">
                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                    </div>

                    <div class="fw-semibold">
                        <?php echo e($user->name); ?>

                    </div>
                </a>


            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php if(auth()->guard()->guest()): ?>
        <p class="text-muted text-center mt-4">
            Login to start chatting
        </p>
        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\New folder\xamp\htdocs\laravel\Reverb\resources\views/welcome.blade.php ENDPATH**/ ?>