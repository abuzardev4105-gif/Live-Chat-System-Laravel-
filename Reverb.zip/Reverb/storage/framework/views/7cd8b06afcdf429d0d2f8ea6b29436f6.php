

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-4">
        <h3 class="mb-4 text-center">Login</h3>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>

            <button class="btn btn-dark w-100">Login</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\New folder\xamp\htdocs\laravel\Reverb\resources\views/auth/login.blade.php ENDPATH**/ ?>