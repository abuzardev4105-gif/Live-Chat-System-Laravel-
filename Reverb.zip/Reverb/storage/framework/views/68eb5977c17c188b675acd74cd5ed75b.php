

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">

        
        <div class="d-flex align-items-center mb-3">
            <a href="<?php echo e(route('welcome')); ?>" class="btn btn-sm btn-light me-2">←</a>
            <h5 class="mb-0 fw-bold"><?php echo e($user->name); ?></h5>
        </div>

        
        <div class="border rounded p-3 mb-3" style="height: 400px; overflow-y: auto;">

            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-2 d-flex
                    <?php echo e($chat->sender_id === auth()->id() ? 'justify-content-end' : 'justify-content-start'); ?>">

                    <div class="px-3 py-2 rounded
                        <?php echo e($chat->sender_id === auth()->id()
                            ? 'bg-dark text-white'
                            : 'bg-secondary'); ?>">
                        <?php echo e($chat->message); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted text-center">No messages yet</p>
            <?php endif; ?>

        </div>

        
        <form method="POST" action="<?php echo e(route('chat.store', $user->id)); ?>">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <input type="text"
                       name="message"
                       class="form-control"
                       placeholder="Type a message..."
                       required>
                <button class="btn btn-dark">Send</button>
            </div>
        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\New folder\xamp\htdocs\laravel\Reverb\resources\views/chat/index.blade.php ENDPATH**/ ?>