@extends('layouts.app')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-6">

        {{-- Header --}}
        <div class="d-flex align-items-center mb-3">
            <a href="{{ route('welcome') }}" class="btn btn-sm btn-light me-2">←</a>
            <h5 class="mb-0 fw-bold">{{ $user->name }}</h5>
        </div>

        {{-- Messages --}}
        <div class="border rounded p-3 mb-3" style="height: 400px; overflow-y: auto;">

            @forelse($messages as $chat)
                <div class="mb-2 d-flex
                    {{ $chat->sender_id === auth()->id() ? 'justify-content-end' : 'justify-content-start' }}">

                    <div class="px-3 py-2 rounded
                        {{ $chat->sender_id === auth()->id()
                            ? 'bg-dark text-white'
                            : 'bg-secondary' }}">
                        {{ $chat->message }}
                    </div>
                </div>
            @empty
                <p class="text-muted text-center">No messages yet</p>
            @endforelse

        </div>

        {{-- Send Message --}}
        <form method="POST" action="{{ route('chat.store', $user->id) }}">
            @csrf
            <div class="input-group">
                <input type="text"
                       name="message"
                       class="form-control"
                       placeholder="Type a message..."
                       required>
                <button class="btn btn-dark">Send</button>
            </div>
        </form>

    </div>
</div>

@endsection
