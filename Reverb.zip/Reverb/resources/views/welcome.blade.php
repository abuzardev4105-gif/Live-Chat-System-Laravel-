@extends('layouts.app')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-6">

        {{-- Header --}}
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold mb-0">Chats</h4>

            @auth
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button class="btn btn-outline-dark btn-sm">Logout</button>
            </form>
            @endauth
        </div>

        {{-- User List --}}
        <div class="list-group shadow-sm">

            @foreach($users as $user)
            <div class="list-group-item d-flex align-items-center gap-3">

                <a href="{{ route('chat.index', $user->id) }}"
                    class="list-group-item d-flex align-items-center gap-3 list-group-item-action">

                    <div class="avatar border py-1 px-2 bg-black text-white fw-bold rounded-circle">
                        {{ strtoupper(substr($user->name, 0, 1)) }}
                    </div>

                    <div class="fw-semibold">
                        {{ $user->name }}
                    </div>
                </a>


            </div>
            @endforeach

        </div>

        @guest
        <p class="text-muted text-center mt-4">
            Login to start chatting
        </p>
        @endguest

    </div>
</div>

@endsection