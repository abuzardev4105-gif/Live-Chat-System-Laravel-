<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/">MyApp</a>

        <div>
            @auth
                <span class="me-3">Hi, {{ auth()->user()->name }}</span>
                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                    @csrf
                    <button class="btn btn-outline-dark btn-sm">Logout</button>
                </form>
            @else
                <a href="{{ route('login') }}" class="btn btn-outline-dark btn-sm me-2">Login</a>
                <a href="{{ route('register') }}" class="btn btn-dark btn-sm">Register</a>
            @endauth
        </div>
    </div>
</nav>

<div class="container py-5">
    @yield('content')
</div>

</body>
</html>
